Objetivo: Mantener el frontend funcional y visualmente agradable, sin complejidades de código innecesarias.
Ámbito: Únicamente esta rama. No propagar cambios a otras ramas salvo indicación explícita.
Alcance: Solo las fases planificadas. Evitar sobre-ingeniería, seguridad excesiva o abstracciones no útiles.
Prioridad: MVP usable, claro y estable.
Guía: Simplicidad, modularidad y diseño consistente.