from django.apps import AppConfig


class ObservacionesConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "backend.observaciones"
    verbose_name = "Observaciones"
