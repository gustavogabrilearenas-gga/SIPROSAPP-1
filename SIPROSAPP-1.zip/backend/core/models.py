"""El módulo ``core`` no define modelos concretos.

Este archivo se mantiene para cumplir con las convenciones de Django y
facilitar futuras extensiones transversales.
"""
