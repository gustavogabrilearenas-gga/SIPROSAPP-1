"""Servicios reutilizables del núcleo de la aplicación."""
