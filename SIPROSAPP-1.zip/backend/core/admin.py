"""Configuración del Django Admin para SIPROSA MES."""

from django.contrib import admin


admin.site.site_header = "SIPROSA MES - Administración"
admin.site.site_title = "SIPROSA MES"
admin.site.index_title = "Sistema de Gestión de Manufactura"
