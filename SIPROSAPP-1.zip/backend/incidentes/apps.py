from django.apps import AppConfig

class IncidentesConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'backend.incidentes'
    verbose_name = 'Incidentes y Paradas'